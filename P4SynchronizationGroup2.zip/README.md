# P4Synchronization

To run the program, run the file 'test.py' located in the 'Tests' folder.